// typing animation effect

var typed= new Typed(".typing",{
    strings:[" ", "Web Designer","Graphic Designer","Web Developer"],
    tyepeSpeed:100,
    BackSpeed:60,
    loop:true
})